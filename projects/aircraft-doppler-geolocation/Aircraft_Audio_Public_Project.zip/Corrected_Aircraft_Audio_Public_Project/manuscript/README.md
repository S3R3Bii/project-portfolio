# Inferring a recording location from aircraft sound

Author: James N. Jean IV.

Corrected-capture-time edition. The fresh archive search ranks the supplied target first by curve RMS among 358 refined candidates under each of two source models. The two RMS-selected location estimates are 56.5 m and 79.1 m from the approximate supplied point. This analysis is post-disclosure, not a new blind test; the reference accuracy is unknown. This manuscript presents only the capture-time analysis.

Build with standard TeX Live:

    bash build.sh

The source uses article, lmodern, microtype, amsmath, amssymb, graphicx, geometry, booktabs, array, xcolor, caption, hyperref and float. Supplied vector PDF figures reproduce the document; PNG versions are provided for reuse. Numerical analysis and figure-generation code belong to the separate evidence/project package, not this typesetting bundle.

PUBLIC: omits exact dates, absolute capture times, flight identifiers, supplied or inferred geographic coordinates, actual geographic maps and original spectral pixels. Anonymous measured curves and scalar comparisons are retained.
