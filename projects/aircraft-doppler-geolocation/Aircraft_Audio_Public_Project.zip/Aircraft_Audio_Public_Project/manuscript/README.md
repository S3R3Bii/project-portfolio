# Public LaTeX manuscript

Build with a standard TeX Live installation:

    bash build.sh

Requires article, lmodern, microtype, amsmath, amssymb, graphicx, geometry, booktabs, array, xcolor, caption, hyperref and float. The included vector PDF figures are used by default; PNG copies are provided for reuse.

Public source contains no private TeX branches, actual geographic figures, original spectrogram pixels, recording date/time or flight identifiers. Actual anonymized measured frequency data are distinguished from schematic illustrations. The target was supplied after the blind search; no independently validated recording coordinate is claimed.
