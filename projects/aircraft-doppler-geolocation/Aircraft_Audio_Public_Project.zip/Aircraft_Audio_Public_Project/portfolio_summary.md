# Inferring a recording location from aircraft sound

A passing aircraft leaves a changing harmonic pattern in a recording. This project extracts that motion in pitch, predicts how sound would arrive from public flight trajectories, and fits the listener geometry.

Two clips of one flyover are placed on their real elapsed-time axis, retaining a 15.16-second gap. The model includes three-dimensional slant distance, sound-travel delay, source-pitch variation, terrain, and a modeled atmosphere. Competing aircraft are compared using both traced-frequency error and direct spectrogram contrast.

The first global search abstained. After approximate time and the aircraft identity were supplied, the controlled comparison tested 42 candidates without a name filter. The supplied target ranked first under one pitch-drift model but not across other objectives and timing assumptions. The resulting observer locations are model estimates, not independently validated camera fixes.

The work demonstrates the complete audio-to-geometry calculation and makes its ambiguities visible. The public release includes a formal LaTeX manuscript, actual anonymous measurements, candidate score tables, reusable propagation code and executable physics checks. Private recordings and geographic hypotheses are excluded.

Suggested figures: `manuscript/figures/measured_curve.png`, `manuscript/figures/flow_counts.png`, `manuscript/figures/type_comparison.png`, `manuscript/figures/score_scatter.png`.
