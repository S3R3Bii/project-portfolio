# Inferring a recording location from aircraft sound

A figure-rich LaTeX case study of a real flyover recording: measured harmonic motion, sound propagation, flight-path comparisons, and observer geometry.

The public manuscript follows the calculation from sound to candidate fits. The blind search abstained. Approximate time and flight identity were supplied later; the subsequent observer estimate is conditional and has not been checked against an actual recording coordinate. Across the controlled comparison, source-pitch and clock assumptions change which aircraft fits best.

## Contents

- `manuscript/`: standalone sanitized LaTeX source, figures, bibliography and compiled PDF.
- `data/`: actual measured frequency versus relative elapsed time, plus anonymous results for all 42 time-intersection candidates. Target A-27 is the user-supplied aircraft.
- `src/doppler.py`: reusable uniform-wind, retarded-time propagation equations.
- `src/plot_measurements.py`: regenerate plots from the public measurements and score table.
- `tests/test_doppler.py`: synthetic finite-difference, propagation-inversion and sign checks.

No recordings, original spectrogram pixels, aircraft identifiers, recording date/time, geographic tracks, observer coordinates or maps are included. The target is an anonymous label, not an independently discovered identity.

## Build and check

Install the Python requirements, then run:

```sh
python tests/test_doppler.py
python src/plot_measurements.py
cd manuscript
./build.sh
```

The manuscript build requires a working TeX Live installation. Its source and included figures are sufficient to rebuild the PDF. Python tests require no network after dependencies are installed. Synthetic checks verify equation consistency, not real-world geolocation accuracy.

The public package reproduces its figures and checks the model equations. Exact private-data fits require the separately archived private evidence bundle, which retains the original trajectories, terrain/weather samples and actual-audio score inputs. Those inputs are intentionally absent here.

## Selected results

A global archive search produced 874 displayed candidate aircraft and a frozen abstention. The later activity intersection contained 42 of those candidates. A controlled terrain/weather extension evaluated 1,720,408 location/time pairs and found 39 primary-window aircraft with covered full-event modes. Under constant pitch, the supplied target ranked 6 th by ridge RMS and 5 th by profiled spectral contrast. Allowing up to 3% source-pitch drift changed those ranks to 1 st and 2 nd. A stricter clock changed them to 12 th and 15 th of 37. These are model-conditional ranks, not identification probabilities.

Archive type codes describe metadata, not an acoustic classifier. A narrow retrospective speed/range screen excluded the supplied target, illustrating why uncalibrated cuts should not be treated as decisive exclusions.

## Sources

The manuscript contains the source references and equations. Core public data: ADSB.lol aircraft archive, NOAA ETOPO 2022 terrain/geoid, and NCEP GFS weather fields. Methodological inspiration is credited in the manuscript references rather than used as evidence that this recording was independently geolocated.
